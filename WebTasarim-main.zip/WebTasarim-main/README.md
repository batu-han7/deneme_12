# Web Tasarım Proje Ödevi
 - Güneş sistemini tanıtan web sitesi 

## Proje sahipleri
 - Hasan koç  19410051015
 - Ayşe Kurkutata  19410051059
 - Batuhan Yanar  18410051069


# Proje detayları


 ![Örnek resim](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Planets2013.svg/1200px-Planets2013.svg.png)
 
# Story Board
  - anasayfa(animasyon sayfası)
![ana sayfa](https://raw.githubusercontent.com/HasanKoc33/WebTasarim/main/gorseller/Ekran%20Al%C4%B1nt%C4%B1s%C4%B1.JPG)
  - bigi sayfası
![detay sayfası](https://raw.githubusercontent.com/HasanKoc33/WebTasarim/main/gorseller/Ekran%20Al%C4%B1nt%C4%B1sa%C4%B1.JPG)


# Proje Tamamlanmıştır
 [projenin çalışır haline buradan ulaşabilirsiniz](https://solarsystem-55bfa.web.app)
